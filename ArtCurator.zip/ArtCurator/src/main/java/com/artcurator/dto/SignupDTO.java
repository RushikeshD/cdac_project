package com.artcurator.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import com.artcurator.pojos.Role;

public class SignupDTO {
	@NotBlank(message = "User name can't be blank")
	private String name;
	@NotBlank(message = "User email can't be blank")
	private String email;
	@NotBlank(message = "User password can't be blank")
	private String password;
	@NotBlank(message = "User phone can't be blank")
	private String phone;
	@NotBlank(message = "User dob can't be blank")
	private LocalDate dob;
	@NotBlank(message = "User role can't be blank")
	private Role role;
	@NotBlank(message = "Address apartment can't be blank")
	private String apartment;
	@NotBlank(message = "Address street can't be blank")
	private String street;
	@NotBlank(message = "Address city can't be blank")
	private String city;
	@NotBlank(message = "Address state can't be blank")
	private String state;
	@NotBlank(message = "Address country can't be blank")
	private String country;
	@NotBlank(message = "Address pin can't be blank")
	private String pin;

	public SignupDTO() {
		super();
	}

	public SignupDTO(@NotBlank(message = "User name can't be blank") String name,
			@NotBlank(message = "User email can't be blank") String email,
			@NotBlank(message = "User password can't be blank") String password,
			@NotBlank(message = "User phone can't be blank") String phone,
			@NotBlank(message = "User dob can't be blank") LocalDate dob,
			@NotBlank(message = "User role can't be blank") Role role,
			@NotBlank(message = "Address apartment can't be blank") String apartment,
			@NotBlank(message = "Address street can't be blank") String street,
			@NotBlank(message = "Address city can't be blank") String city,
			@NotBlank(message = "Address state can't be blank") String state,
			@NotBlank(message = "Address country can't be blank") String country,
			@NotBlank(message = "Address pin can't be blank") String pin) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.dob = dob;
		this.role = role;
		this.apartment = apartment;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pin = pin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getApartment() {
		return apartment;
	}

	public void setApartment(String apartment) {
		this.apartment = apartment;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "SignupDTO [name=" + name + ", email=" + email + ", password=" + password + ", phone=" + phone + ", dob="
				+ dob + ", role=" + role + ", apartment=" + apartment + ", street=" + street + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", pin=" + pin + "]";
	}
	
}
