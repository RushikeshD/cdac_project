package com.artcurator.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artcurator.dao.AddressRespository;
import com.artcurator.dao.UserRepository;
import com.artcurator.pojos.Address;
import com.artcurator.pojos.User;

@Service
@Transactional
public class AddressServiceImpl implements IAddressService {
	@Autowired
	private UserRepository userRepo;
	
	@Autowired 
	AddressRespository addressRepository;
	
	@Override
	public String updateAddress(int user_id, int addr_id, Address address) {
		String status = "Address updated.";

//		Optional<User> userOptional = userRepo.findById(id);
//
//		if (userOptional.isPresent()) {
//			List<Address> addresses = userOptional.get().getAddresses();
//
//			for (Address addr : addresses) {
//				if (addr.getId() == id) {
//					addr.setApartment(address.getApartment());
//					addr.setStreet(address.getStreet());
//					addr.setCity(address.getCity());
//					addr.setState(address.getState());
//					addr.setCountry(address.getCountry());
//					addr.setPin(address.getPin());
//
//					break;
//				}
//			}
//
//			return "Your address is updated.";
//		}
		address.setId(addr_id);
		address.setUser(new User(user_id));
		addressRepository.save(address);
		return status;
	}
	
	@Override
	public List<Address> getAddresses(int id) {
		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			userOptional.get().getAddresses().size();
			return userOptional.get().getAddresses();
		}

		return null;
	}
	
	@Override
	public String addAddress(int id, Address address) {
		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			System.out.println("In if.");
			userOptional.get().addAddress(address);
			System.out.println("After if.");
			return "Address is added.";
		}

		return "Address couldn't be added.";
	}

	@Override
	public String deleteAddress(int user_id, int addr_id) {
		Optional<User> userOptional = userRepo.findById(user_id);

		if (userOptional.isPresent()) {
			User user =  userOptional.get();
			List<Address> addresses = user.getAddresses();

			for (Address addr : addresses) {
				if (addr.getId() == addr_id) {
					user.removeAddress(addr);
					return "Your address is deleted.";
				}
			}
		}
		
		return "Address not deleted.";
		
//		addressRepository.deleteById(addr_id);
//		return "Deleted.";
	}
}
