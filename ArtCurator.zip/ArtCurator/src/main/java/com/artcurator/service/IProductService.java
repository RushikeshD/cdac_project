package com.artcurator.service;

import java.util.List;
import java.util.Optional;

import com.artcurator.pojos.Product;

public interface IProductService {
	List<Product> getProducts(String category, String query);
	List<Product> findAllProducts();
	Product addProduct(Product product,int id);
	Optional<Product> findByName(String name);
	String deleteById(Integer id);
	List<Product> findAllUnsoldProducts();
	List<Product> findAllSoldProducts();
	Optional<Product> findById(Integer id);
	byte[] getImage(int id);
}
