package com.artcurator.service;

import java.util.List;

import com.artcurator.pojos.Address;

public interface IAddressService {

	String updateAddress(int user_id, int addr_id, Address address);

	String deleteAddress(int user_id, int addr_id);

	String addAddress(int id, Address address);

	List<Address> getAddresses(int id);
	
}
