package com.artcurator.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.artcurator.pojos.Address;
import com.artcurator.pojos.User;

public interface IUserService {
	Optional<User> getUserById(int id);
	String updatePassword(int id, String oldPassword, String newPassword);
	String changeEmail(int id, String newEmail);
	String changePhone(int id, String phone);
	User getUser(int id);
	Optional<User> findByEmailAndPassword(String email, String password);
	//void decryptPassword(int id);
	boolean getUserByEmailAndDob(String email, LocalDate dob);
	String getRole(int id);
	Optional<User> findUserByEmail(String email);
	Optional<User> findUserById(Integer id);
	User addUser(User user,Address address);
	List<User> findAllUser();
	String changePassword(String email, String newPassword);
}