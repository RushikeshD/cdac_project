package com.artcurator.service;

import java.util.Optional;

import com.artcurator.pojos.Wallet;

public interface IWalletService {
	Optional<Wallet> findByUser_id(Integer id);
	
	Wallet addMoneyToWallet(Integer user_id,double amount);
}
