package com.artcurator.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.artcurator.dao.ProductRepository;
import com.artcurator.dao.UserRepository;
import com.artcurator.pojos.Product;
import com.artcurator.pojos.Status;
import com.artcurator.pojos.User;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository productRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public List<Product> getProducts(String category, String query) {
		return productRepo.getProducts(category, query);
	}
	
	@Override
	public List<Product> findAllProducts() {
		return productRepo.findAll(Sort.by("quantity"));
	}

	@Override
	public Optional<Product> findByName(String name) {
		return productRepo.findByName(name);
	}
	
	@Override
	public Product addProduct(Product product,int id) {
		System.out.println("In add service");
		Optional<User> u = userRepo.findById(id);	// was userRepo.findUser before.
		if(u.isPresent())
			product.setUser(u.get());
		return productRepo.save(product);
	}

	@Override
	public String deleteById(Integer id) {
		productRepo.deleteById(id);
		return "Product Deleted";
	}

	@Override
	public List<Product> findAllUnsoldProducts() {
		return productRepo.findAllByStatus(Status.UNSOLD);
	}
 
	@Override
	public List<Product> findAllSoldProducts() {
		System.out.println("In "+Status.SOLD.toString());
		return productRepo.findAllByStatus(Status.SOLD);
	}

	@Override
	public Optional<Product> findById(Integer id) {
		// TODO Auto-generated method stub
		return productRepo.findById(id);
	}

	@Override
	public byte[] getImage(int id) {
		return productRepo.getImage(id);
	}
}