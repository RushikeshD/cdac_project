/**
 * 
 */
package com.artcurator.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artcurator.dao.UserRepository;
import com.artcurator.dao.WalletRepository;
import com.artcurator.pojos.Wallet;

@Service
@Transactional
public class WalletServiceImpl implements IWalletService {

	@Autowired
	private WalletRepository walletRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public Optional<Wallet> findByUser_id(Integer id) {
		return walletRepo.findById(id);
	}
	
	@Override
	public Wallet addMoneyToWallet(Integer user_id,double amount) {
		Optional<Wallet> wallet=walletRepo.findByUser_id(user_id);
		if(wallet.isPresent()) {
			wallet.get().setAmount(wallet.get().getAmount()+amount);
		}else {
			Wallet newWallet=new Wallet();
			newWallet.setAmount(amount);
			newWallet.setUser(userRepo.findById(user_id).get());
			return walletRepo.save(newWallet);
		}
		return walletRepo.save(wallet.get());
	}
} 
