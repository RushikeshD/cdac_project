package com.artcurator.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.artcurator.dao.AddressRespository;
import com.artcurator.dao.UserRepository;
import com.artcurator.pojos.Address;
import com.artcurator.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Autowired
	AddressRespository addressRepository;

	@Override
	public boolean getUserByEmailAndDob(String email, LocalDate dob) {
		if (userRepo.findByEmailAndDob(email, dob).isPresent()) {
			return true;
		}

		return false;
	}

	@Override
	public Optional<User> getUserById(int id) {
		return userRepo.findById(id);
	}

	@Override
	public String changePassword(String email, String newPassword) {
		String status = "Password change encountered some error.";

		Optional<User> userOptional = userRepo.findByEmail(email);

		if (userOptional.isPresent()) {
			userOptional.get().setPassword(encoder.encode(newPassword));
			return "Your password is changed. Please login again.";
		}

		return status;
	}

	@Override
	public String updatePassword(int id, String oldPassword, String newPassword) {
		String status = "Password change encountered some error.";
		String encodedPassword = encoder.encode(oldPassword);

		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			if (encodedPassword.equals(userOptional.get().getPassword())) {
				return "Wrong password. Please try again.";
			}
			userOptional.get().setPassword(encoder.encode(newPassword));
			return "Your password is changed. Please login again.";
		}

		return status;
	}

	@Override
	public String changeEmail(int id, String newEmail) {
		String status = "Email change encountered some error.";

		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			userOptional.get().setEmail(newEmail);
			return "Your email is changed.";
		}

		return status;
	}

	@Override
	public String changePhone(int id, String phone) {
		String status = "Phone change encountered some error.";

		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			userOptional.get().setPhone(phone);
			return "Your phone is changed.";
		}

		return status;
	}

	@Override
	public User getUser(int id) {
		Optional<User> userOptional = userRepo.findById(id);

		if (userOptional.isPresent()) {
			User user = userOptional.get();
			user.getAddresses().size();

			return user;
		}

		return null;
	}

	@Override
	public Optional<User> findByEmailAndPassword(String email, String password) {
		return userRepo.findByEmailAndPassword(email, password);
	}

//	@Override
//	public void decryptPassword(int id) {
//		Optional<User> userOptional = userRepo.findById(id);
//		
//		if(userOptional.isPresent()) {
//			userOptional.get().setPassword(encoder.encode(userOptional.get().getPassword()));
//		}
//	}

	@Override
	public String getRole(int id) {
		return userRepo.findById(id).get().getRole().toString();
	}

	@Override
	public User addUser(User user, Address address) {
		user.addAddress(address);
		user.setPassword(encoder.encode(user.getPassword()));

		return userRepo.save(user);
	}

	@Override
	public Optional<User> findUserByEmail(String email) {
		return userRepo.findByEmail(email);
	}

	@Override
	public List<User> findAllUser() {
		return userRepo.findAll();
	}

	@Override
	public Optional<User> findUserById(Integer id) {
		return userRepo.findById(id);
	}
}
