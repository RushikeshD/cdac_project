package com.artcurator.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.artcurator.dao.CartRepository;
import com.artcurator.pojos.Cart;

@Service
@Transactional
public class CartServiceImpl implements ICartService {

	@Autowired
	private CartRepository cartRepo;

	@Override
	public Cart addProduct(Cart cart) {
		return cartRepo.save(cart);
	}

	@Override
	public String deleteProduct(int id) {
		cartRepo.deleteById(id);
		return "Product deleted from cart";
	}

	@Override
	public List<Cart> getAllProductsByUserId(int id) {
		// TODO Auto-generated method stub
		return cartRepo.findByUserId(id);
	}
	
}