package com.artcurator.service;

import java.util.List;

import com.artcurator.pojos.Cart;

public interface ICartService {
	Cart addProduct(Cart cart);
	String deleteProduct(int id);
	List<Cart> getAllProductsByUserId(int id);
}
