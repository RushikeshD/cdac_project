package com.artcurator.controller;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/buyer")
public class BuyerController {
	public BuyerController() {
		System.out.println("In BuyerController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of BuyerController.");
	}
}