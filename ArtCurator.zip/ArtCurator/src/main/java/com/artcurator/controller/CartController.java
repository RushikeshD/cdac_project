package com.artcurator.controller;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artcurator.pojos.Cart;
import com.artcurator.pojos.Product;
import com.artcurator.pojos.User;
import com.artcurator.service.ICartService;
import com.artcurator.service.IProductService;
import com.artcurator.service.IUserService;

@RestController
@RequestMapping("/cart")
@CrossOrigin
public class CartController {

	@Autowired
	private IUserService userService;

	@Autowired
	private IProductService productService;

	@Autowired
	private ICartService cartService;

	public CartController() {
		System.out.println("In CartController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of CartController.");
	}
	
	@GetMapping("/getall/{id}")
	public ResponseEntity<?> getAllProductsFromUserCart(@PathVariable int id){//Fetching all product from cart with {USER_ID}
		try {
			List<Cart> cart=cartService.getAllProductsByUserId(id);
			if(cart.isEmpty())
				return new ResponseEntity<>("Failed to fetch user cart from database", HttpStatus.BAD_GATEWAY);
			return new ResponseEntity<>(cart,HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/add")
	public ResponseEntity<?> addProductToCart(@RequestParam int user_id, @RequestParam int product_id) {//Adding product in cart with {PRODUCT_ID,USER_ID}
		try {
			Optional<User> user = userService.findUserById(user_id);
			if (!user.isPresent())
				return new ResponseEntity<>("Failed to find user in database", HttpStatus.BAD_GATEWAY);
			Optional<Product> product = productService.findById(product_id);
			if (!product.isPresent())
				return new ResponseEntity<>("Failed to find product in database", HttpStatus.BAD_GATEWAY);
			System.out.println("image ::: " + product.get().getImage());
			Cart cart = new Cart(product.get().getPrice(), user_id, product_id, product.get().getImage(),
					user.get().getName());
			cartService.addProduct(cart);
			return new ResponseEntity<>(product.get().getName() + " Added to cart", HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProductFromCart(@PathVariable int id){//Deleting using {CART_ID}
		try {
			String deleteMsg=cartService.deleteProduct(id);
			if(deleteMsg==null)
				return new ResponseEntity<>("Failed to delete product from cart",HttpStatus.BAD_GATEWAY);
			return new ResponseEntity<>(deleteMsg,HttpStatus.OK);
		}catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
