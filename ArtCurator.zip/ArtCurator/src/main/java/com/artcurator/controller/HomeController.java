package com.artcurator.controller;

import javax.annotation.PostConstruct;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/home")
public class HomeController {
	public HomeController() {
		System.out.println("In HomeController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of HomeController.");
	}

	@GetMapping("/{name}")
	public ResponseEntity<?> sayHello(@PathVariable("name") String name) {
		return ResponseEntity.ok("Hello there, " + name);
	}
}