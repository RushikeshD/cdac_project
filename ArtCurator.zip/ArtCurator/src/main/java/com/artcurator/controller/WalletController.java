package com.artcurator.controller;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artcurator.pojos.Wallet;
import com.artcurator.service.IWalletService;

@RestController
@RequestMapping("/wallet")
@CrossOrigin
public class WalletController {
	
	@Autowired
	private IWalletService walletService;
	
	public WalletController() {
		System.out.println("In WalletController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of WalletController.");
	}
	
	@GetMapping("/seller/{user_id}") //API for Seller to view his wallet using {USER_ID}
	public ResponseEntity<?> getSellerWallet(@PathVariable int user_id){
		try {
		Optional<Wallet> wallet=walletService.findByUser_id(user_id); 
		if(wallet.isPresent())
			return new ResponseEntity<>(wallet.get(),HttpStatus.OK);
		return new ResponseEntity<>("Your wallet is empty. None of your products are sold!!",HttpStatus.BAD_REQUEST);
		}catch (RuntimeException e) {
			return new ResponseEntity<>("Failed to load wallet.",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	 
	@GetMapping("/buyer/{user_id}") //API for Buyer to view his wallet using {USER_ID}
	public ResponseEntity<?> getBuyerWallet(@PathVariable int user_id){
		try {
		Optional<Wallet> wallet=walletService.findByUser_id(user_id); 
		if(wallet.isPresent())
			return new ResponseEntity<>(wallet.get(),HttpStatus.OK); 
		return new ResponseEntity<>("Your wallet is empty. Please add some money!!",HttpStatus.BAD_REQUEST);
		}catch (RuntimeException e) {
			return new ResponseEntity<>("Failed to load wallet.",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/buyer") //API for buyer to add amount in wallet before placing order using {USER_ID,AMOUNT}
	public ResponseEntity<?> updateBuyerWallet(@RequestParam int user_id,@RequestParam double amount){
		try {
			Wallet wallet=walletService.addMoneyToWallet(user_id, amount);
		if(wallet==null) 
			return new ResponseEntity<>("Failed to add money to wallet. Please try again!!",HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(wallet,HttpStatus.OK);
		}catch (RuntimeException e) {
			return new ResponseEntity<>("Failed to load wallet.",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}