package com.artcurator.controller;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/seller")
public class SellerController {
	public SellerController() {
		System.out.println("In SellerController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of SellerController.");
	}
}