package com.artcurator.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artcurator.dto.AuthenticationRequest;
import com.artcurator.dto.AuthenticationResponse;
import com.artcurator.dto.SignupDTO;
import com.artcurator.pojos.Address;
import com.artcurator.pojos.User;
import com.artcurator.service.IUserService;
import com.artcurator.util.JwtUtil;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {

	@Autowired
	private AuthenticationManager mgr;
	@Autowired
	private UserDetailsService service;
	@Autowired
	private JwtUtil utils;
	@Autowired
	private IUserService userService;

	public UserController() {
		System.out.println("In UserController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of UserController.");
	}

	@GetMapping("/login")
	public ResponseEntity<?> createJwtToken(@RequestBody AuthenticationRequest req) {
		try {
			System.out.println(req.getUserName() + " " + req.getPassword());
			mgr.authenticate(new UsernamePasswordAuthenticationToken(req.getUserName(), req.getPassword()));
		} catch (BadCredentialsException e) {
			throw new RuntimeException("Invalid Email or password");
		}

		UserDetails details = service.loadUserByUsername(req.getUserName());
		return ResponseEntity.ok(new AuthenticationResponse(utils.generateToken(details)));
	}

	@PostMapping("/signup")
	public ResponseEntity<?> addUserAccount(@RequestBody SignupDTO dto) {
		try {
			if (dto == null)
				return new ResponseEntity<>("Signup form submition failed", HttpStatus.NO_CONTENT);
			if (userService.findUserByEmail(dto.getEmail()).isPresent())
				return new ResponseEntity<>("User email allready present", HttpStatus.BAD_REQUEST);
			User user = new User(dto.getName(), dto.getEmail(), dto.getPassword(), dto.getPhone(), dto.getDob(),
					dto.getRole());
			Address address = new Address(dto.getApartment(), dto.getStreet(), dto.getCity(), dto.getState(),
					dto.getCountry(), dto.getPin());
			User newUser = userService.addUser(user, address);
			if (newUser == null)
				return new ResponseEntity<>("Error during adding user", HttpStatus.BAD_GATEWAY);
			return new ResponseEntity<>(newUser, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/forgotpassword") // authentication check, if email matches dob then send ok and take new
	// Password.
	public ResponseEntity<?> forgotPassword(@RequestParam String email,
			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dob) {

		try {
			if (userService.getUserByEmailAndDob(email, dob)) {
				return ResponseEntity.ok(true);
			}

			return new ResponseEntity<>(false, HttpStatus.NOT_FOUND);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/changepassword")
	public ResponseEntity<?> changePassword(String email, String newPassword) {
		String status = "";

		try {
			status = userService.changePassword(email, newPassword);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/updatepassword") // After log in my account page.
	public ResponseEntity<?> updatePassword(@RequestParam int id, @RequestParam String oldPassword,
			@RequestParam String newPassword) {
		String status = "";

		try {
			status = userService.updatePassword(id, oldPassword, newPassword);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/changeemail")
	public ResponseEntity<?> changeEmail(@RequestParam int id, @RequestParam String newEmail) {
		String status = "";

		try {
			status = userService.changeEmail(id, newEmail);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/changephone")
	public ResponseEntity<?> changePhone(@RequestParam int id, @RequestParam String phone) {
		String status = "";

		try {
			status = userService.changePhone(id, phone);
			return new ResponseEntity<>(status, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getUserById(@PathVariable int id) {
		Optional<User> users = userService.findUserById(id);

		try {
			if (!users.isPresent())
				return new ResponseEntity<>("No Users in database", HttpStatus.NO_CONTENT);
			return new ResponseEntity<>(users.get(), HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getuserbyid")
	public ResponseEntity<?> getUser(@RequestParam int id) {
		Optional<User> userOptional = userService.getUserById(id);

		try {
			if (userOptional.isPresent()) {
				return ResponseEntity.ok(userOptional.get());
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/role")
	public ResponseEntity<?> getRole(@RequestParam int id) {
		System.out.println(userService.getRole(id));
		try {
			return ResponseEntity.ok(userService.getRole(id));
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getuserfromtoken")
	public ResponseEntity<?> getUserFromToken(HttpServletRequest request) {
		UserDetails userDetails = service
				.loadUserByUsername(utils.extractUsername(request.getHeader("Authorization").substring(7)));
		Optional<User> userOptional = userService.findUserByEmail(userDetails.getUsername());

		if (userOptional.isPresent()) {
			return new ResponseEntity<>(userOptional.get().getId(), HttpStatus.OK);
		}

		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	/*
	 * @GetMapping public Long getTestsListByUserId(HttpServletRequest req) { String
	 * authHeader = req.getHeader("Authorization"); String jwt =
	 * authHeader.substring(7); UserDetails user =
	 * UserDetailsService.loadUserByUsername(utils.extractUsername(jwt));
	 * PaperSetter paperSetter = service.getByEmail(user.getUsername()); return
	 * paperSetter.getPaperSetterId();
	 */

//@GetMapping("/encrypt/{id}")
//public String encryptIt(@PathVariable int id) {
//userService.decryptPassword(id);
//return "Encrypted.";
//}
}