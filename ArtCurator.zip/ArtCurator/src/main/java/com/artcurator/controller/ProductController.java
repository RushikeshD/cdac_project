package com.artcurator.controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.artcurator.pojos.Product;
import com.artcurator.service.IProductService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private IProductService productService;

	public ProductController() {
		System.out.println("In ProductController constructor.");
	}

	@PostConstruct
	public void init() {
		System.out.println("In init of ProductController.");
	}

	@GetMapping
	public ResponseEntity<?> getProducts(@RequestParam("category") String category,
			@RequestParam("search_query") String query) {
		List<Product> products = productService.getProducts(category, "%" + query + "%");

		if (products.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@GetMapping("/getall")
	public ResponseEntity<?> getAllProducts() {
		List<Product> products = productService.findAllProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@PostMapping("/add/{id}")
	public ResponseEntity<?> addProduct(@PathVariable int id, @RequestParam String dtls,
			@RequestParam MultipartFile imageFile) {
		try {
			Product product = new ObjectMapper().readValue(dtls, Product.class);
			if (product == null)
				return new ResponseEntity<>("Product form submition failed", HttpStatus.NO_CONTENT);
			product.setImage(imageFile.getBytes());
			product.setImage_type(imageFile.getContentType());

//			Optional<Product> isProductExist = service.findByName(product.getName());
//			System.out.println("After check");
//			if (isProductExist.isPresent())
//				return new ResponseEntity<>("Product allready present", HttpStatus.ALREADY_REPORTED);
//			System.out.println("Product : "+isProductExist.get());
			Product newProduct = productService.addProduct(product, id);
			if (newProduct == null)
				return new ResponseEntity<>("Error during adding product", HttpStatus.BAD_REQUEST);
			return new ResponseEntity<>("File uploaded : " + imageFile.getOriginalFilename(), HttpStatus.OK);
		} catch (RuntimeException | IOException e) {
			return new ResponseEntity<>("Error during processing image ", HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id) {
		String msgString = productService.deleteById(id);
		return new ResponseEntity<>(msgString, HttpStatus.OK);
	}

	@GetMapping("/unsold")
	public ResponseEntity<?> getAllUnSold() {
		List<Product> products = productService.findAllUnsoldProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@GetMapping("/sold")
	public ResponseEntity<?> getAllSold() {
		List<Product> products = productService.findAllSoldProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}
	
	@GetMapping("/image/{id}")
	public ResponseEntity<?> getProductImage(@PathVariable int id) {
		byte[] products = productService.getImage(id);

		if (products==null) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<>(products, HttpStatus.OK);
	}
}
