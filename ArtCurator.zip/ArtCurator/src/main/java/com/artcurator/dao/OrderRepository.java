package com.artcurator.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.artcurator.pojos.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {

}
