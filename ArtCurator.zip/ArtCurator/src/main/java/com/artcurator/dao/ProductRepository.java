package com.artcurator.dao;

import java.util.List;
import java.util.Optional;

import net.bytebuddy.asm.Advice.OffsetMapping.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artcurator.pojos.Product;
import com.artcurator.pojos.Status;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	@Query("SELECT p FROM Product p where p.category = :category AND p.name like :query")
	List<Product> getProducts(String category, String query);

	@Query(value = "select p from Product p")
	List<Product> findAll(Sort sort);

	Optional<Product> findByName(String name);

	@SuppressWarnings("unchecked")
	Product save(Product p);

	void deleteById(int id);

	List<Product> findAllByStatus(Status status);
	
	Optional<Product> findById(Integer id);
	
	@Query(value = "select p.image from Product p where p.id=:id")
	byte[] getImage(@Param("id")int id);
}