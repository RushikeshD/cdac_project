package com.artcurator.pojos;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "Cart")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "amount")
	private double amount;

	@Column(name = "user_id")
	private Integer user_id;

	@Column(name = "product_id")
	private Integer product_id;

	@Lob
	@Column(name = "image")
	private byte[] image;

	@Column(name = "artist_name")
	private String artist_name;

//	@ManyToOne
//	@JoinColumn(name = "user_id")
//	private User user;
//
//	@ManyToOne
//	@JoinColumn(name = "product_id")
//	private Product product;

	public Cart() {
	}

	public Cart(double amount, Integer user_id, Integer product_id, byte[] image, String artist_name) {
		super();
		this.amount = amount;
		this.user_id = user_id;
		this.product_id = product_id;
		this.image = image;
		this.artist_name = artist_name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getProduct_id() {
		return product_id;
	}

	public void setProduct_id(Integer product_id) {
		this.product_id = product_id;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getArtist_name() {
		return artist_name;
	}

	public void setArtist_name(String artist_name) {
		this.artist_name = artist_name;
	}

	@Override
	public String toString() {
		return "Cart [id=" + id + ", amount=" + amount + ", user_id=" + user_id + ", product_id=" + product_id
				+ ", image=" + Arrays.toString(image) + ", artist_name=" + artist_name + "]";
	}

}
