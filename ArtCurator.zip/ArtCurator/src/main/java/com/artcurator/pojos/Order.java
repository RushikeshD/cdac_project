package com.artcurator.pojos;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

/*CREATE TABLE Orders (
	o_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
	p_id INT UNSIGNED NOT NULL,
    u_id INT UNSIGNED NOT NULL,
	o_timestamp DATETIME NOT NULL,
    FOREIGN KEY (p_id)
		REFERENCES Product (p_id)
        ON DELETE CASCADE,
    FOREIGN KEY (u_id)
		REFERENCES Users (u_id)
        ON DELETE CASCADE
);*/

@Entity
@Table(name = "Orders") 
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@DateTimeFormat(iso=ISO.DATE_TIME)
	@Column(name = "order_time")
	private LocalDateTime timestamp;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	@ManyToOne
	@JoinColumn(name="product_id")
	private Product product;
	
	

	public Order(Integer id, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.timestamp = timestamp;
	}

	public Order() {
		super();
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", timestamp=" + timestamp + "]";
	}
}
