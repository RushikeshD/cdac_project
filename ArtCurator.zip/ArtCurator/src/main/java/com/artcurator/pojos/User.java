package com.artcurator.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonIgnore;

/*
 	CREATE TABLE Users (
	u_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    u_name VARCHAR(255) NOT NULL,
    u_email VARCHAR(50) NOT NULL UNIQUE,
    u_password VARCHAR(50) NOT NULL,
    u_phone VARCHAR(11) NOT NULL,
    u_dob DATE NOT NULL,
    u_role VARCHAR(10)
);
 * */

@Entity
@Table(name = "User")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private Integer id;
	
	@Column(name = "name", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String name;

	@Column(name = "email", unique = true, nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String email;
	
	@Column(name = "password", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	@JsonIgnore
	private String password;
	
	@Column(name = "phone", unique = false, length = 11, nullable = false)
	@NotNull
	private String phone;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd",iso=ISO.DATE)
	@Column(name = "dob", nullable = false)
	private LocalDate dob;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "role", nullable = false)
	private Role role;
	
//	@JsonIgnore
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL, fetch = FetchType.EAGER,orphanRemoval = true)
	private List<Address> addresses = new ArrayList<Address>();
	
	@OneToOne(mappedBy = "user",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Wallet wallet;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Cart> carts = new ArrayList<>();
	
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Product> products = new ArrayList<>();
	
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Order> orders = new ArrayList<>();

	public User(@Size(min = 4, max = 75) @NotNull String name,
			@Size(min = 4, max = 75) @NotNull String email, @Size(min = 4, max = 75) @NotNull String password,
			@NotNull String phone, LocalDate dob, Role role) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.dob = dob;
		this.role = role;
	}

	public User() {
		super();
	}
	
	public User(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	
	// Helper methods
	// Address helper
	public void addAddress(Address address) {
		this.addresses.add(address);
		address.setUser(this);
	}
	
	public void removeAddress(Address address) {
		this.addresses.remove(address);
		address.setUser(null);
	}
	
	// Product Helper
	public void addProduct(Product product) {
		this.products.add(product);
		product.setUser(this);
	}
	
	public void removeProduct(Product product) {
		this.products.remove(product);
		product.setUser(null);
	}
	
	// Order helper
	public void addOrder(Order order) {
		this.orders.add(order);
		order.setUser(this);
	}
	
	public void removeOrder(Order order) {
		this.orders.remove(order);
		order.setUser(null);
	}
	
//	// Cart helper
//	public void addCart(Cart cart) {
//		this.carts.add(cart);
//		cart.setUser(this);
//	}
//	
//	public void removeCart(Cart cart) {
//		this.carts.remove(cart);
//		cart.setUser(null);
//	}
	
	// Wallet helper
	public void addWallet(Wallet wallet) {
		this.wallet = wallet;
		wallet.setUser(this);
	}
	
	public void removeWallet(Wallet wallet) {
		this.wallet = null;
		wallet.setUser(null);
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", phone=" + phone
				+ ", dob=" + dob + ", role=" + role + "]";
	}
}