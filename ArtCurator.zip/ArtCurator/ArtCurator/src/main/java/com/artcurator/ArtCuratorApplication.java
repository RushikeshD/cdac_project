package com.artcurator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtCuratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtCuratorApplication.class, args);
	}

}
