package com.artcurator.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.artcurator.pojos.Product;
import com.artcurator.pojos.Status;

import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

public interface ProductRepo extends JpaRepository<Product, Integer> {
	@Query(value = "select p from Product p")
	List<Product> findAll(Sort sort);
	
	Optional<Product> findByName(String name);
	
	@SuppressWarnings("unchecked")
	Product save(Product p);
	
	void deleteById(int id);

	List<Product> findAllByStatus(Status status);
}
