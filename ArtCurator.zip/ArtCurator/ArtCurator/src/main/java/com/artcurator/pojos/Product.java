package com.artcurator.pojos;

import java.util.Arrays;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/*p_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    p_name VARCHAR(255) NOT NULL,
    p_category VARCHAR(50),
    p_price DECIMAL(10, 2) NOT NULL,
    p_description TEXT NOT NULL,
    p_image BLOB NOT NULL,
    p_image_type VARCHAR(50) NOT NULL,
    p_status VARCHAR(10) NOT NULL,
    seller_id INT UNSIGNED NOT NULL,
    FOREIGN KEY (seller_id)
		REFERENCES Users (u_id)
        ON DELETE CASCADE*/

@Entity
@Table(name = "Product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "name", nullable = false)
	@Size(min = 4, max = 75)
	@NotNull
	private String name;

	@Column(name = "category", nullable = false)
	@Size(min = 4, max = 75)
	@NotNull
	private String category;

	@Column(name = "price", columnDefinition = "decimal(10, 2)")
	@Min(value = 0)
	private double price;

	@Column(name = "description", nullable = true)
	private String description;

	@Lob
	@Column(name = "image")
	private byte[] image;

	@Column(name = "image_type", length = 50, nullable = false)
	private String image_type;

	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false)
	private Status status;

	@Column(name = "quantity")
	private Integer quantity;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private User user;

	public Product() {
		super();
	}

	public Product(@Size(min = 4, max = 75) @NotNull String name,
			@Size(min = 4, max = 75) @NotNull String category, @Min(0) double price, String description, byte[] image,
			String image_type, Status status, Integer quantity) {
		super();
		this.name = name;
		this.category = category;
		this.price = price;
		this.description = description;
		this.image = image;
		this.image_type = image_type;
		this.status = status;
		this.quantity = quantity;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getImage_type() {
		return image_type;
	}

	public void setImage_type(String image_type) {
		this.image_type = image_type;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", price=" + price + ", description="
				+ description + ", image=" + Arrays.toString(image) + ", image_type=" + image_type + ", status="
				+ status + ", quantity=" + quantity + "]";
	}

}
