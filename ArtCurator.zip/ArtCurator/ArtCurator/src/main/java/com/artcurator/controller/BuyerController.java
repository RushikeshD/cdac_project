package com.artcurator.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.artcurator.pojos.Product;

@RestController
@CrossOrigin
@RequestMapping("/buyer")
public class BuyerController {
	public BuyerController() {
		System.out.println("In BuyersController().");
	}
	
	@PostConstruct
	public void init() {
		System.out.println("in init ");
	}	
}