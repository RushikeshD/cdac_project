package com.artcurator.service;

public interface SellerService {

}
