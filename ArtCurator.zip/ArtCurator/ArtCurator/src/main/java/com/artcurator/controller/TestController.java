package com.artcurator.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("In testController constructor.");
	}
	
	@GetMapping("/hello")
	public ResponseEntity<?> greetings() {
		return ResponseEntity.ok("Hellooooooooo.");
	}
}