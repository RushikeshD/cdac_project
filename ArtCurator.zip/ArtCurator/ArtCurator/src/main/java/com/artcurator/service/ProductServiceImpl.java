package com.artcurator.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.artcurator.dao.ProductRepo;
import com.artcurator.pojos.Product;
import com.artcurator.pojos.Status;
import com.artcurator.pojos.User;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo repo;
	
	@Autowired
	private UserService urepo;
	
	@Override
	public List<Product> findAllProducts() {
		return repo.findAll(Sort.by("quantity"));
	}

	@Override
	public Optional<Product> findByName(String name) {
		return repo.findByName(name);
	}
	
	@Override
	public Product addProduct(Product product,int id) {
		System.out.println("In add service");
		Optional<User> u=urepo.findUser(id);
		if(u.isPresent())
			product.setUser(u.get());
		return repo.save(product);
	}

	@Override
	public String deleteById(Integer id) {
		repo.deleteById(id);
		return "Product Deleted";
	}

	@Override
	public List<Product> findAllUnsoldProducts() {
		return repo.findAllByStatus(Status.UNSOLD);
	}
 
	@Override
	public List<Product> findAllSoldProducts() {
		System.out.println("In "+Status.SOLD.toString());
		return repo.findAllByStatus(Status.SOLD);
	} 
}
