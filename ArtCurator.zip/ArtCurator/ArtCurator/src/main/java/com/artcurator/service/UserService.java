package com.artcurator.service;

import java.util.Optional;

import com.artcurator.pojos.User;

public interface UserService {
	Optional<User> findUser(int id);
}
