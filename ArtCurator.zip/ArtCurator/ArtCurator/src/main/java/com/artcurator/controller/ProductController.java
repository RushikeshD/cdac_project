package com.artcurator.controller;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.artcurator.pojos.Product;
import com.artcurator.service.ProductService;

@RestController
@CrossOrigin
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService service;

	public ProductController() {
		System.out.println("In Product Controller().");
	}
   
	@PostConstruct
	public void init() {
		System.out.println("In init ");
	}

	@GetMapping("/getall")
	public ResponseEntity<?> getAllArts() {
		List<Product> products = service.findAllProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@PostMapping("/add/{id}")
	public ResponseEntity<?> addProduct(@PathVariable int id,@RequestBody Product product) {
		if (product == null)   
			return new ResponseEntity<>("Procuct json is in-complete", HttpStatus.NO_CONTENT);
		Optional<Product> isProductExist = service.findByName(product.getName());
		if (isProductExist.isPresent())
			return new ResponseEntity<>("Product allready present", HttpStatus.ALREADY_REPORTED);
		Product newProduct = service.addProduct(product,id);
		if (newProduct == null)
			return new ResponseEntity<>("Error during adding product", HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(newProduct, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id) {	
		String  msgString=service.deleteById(id);
		return new ResponseEntity<>(msgString,HttpStatus.OK);
	}
	
	@GetMapping("/unsold")
	public ResponseEntity<?> getAllUnSold() {
		List<Product> products = service.findAllUnsoldProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}
	
	@GetMapping("/sold")
	public ResponseEntity<?> getAllSold() {
		List<Product> products = service.findAllSoldProducts();
		if (products.isEmpty())
			return new ResponseEntity<>("No Products in database", HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}
}
