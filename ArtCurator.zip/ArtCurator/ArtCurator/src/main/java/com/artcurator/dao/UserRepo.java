package com.artcurator.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.artcurator.pojos.User;

public interface UserRepo extends JpaRepository<User, Integer> {

}
