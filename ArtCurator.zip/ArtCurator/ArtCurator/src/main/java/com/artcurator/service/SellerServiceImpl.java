package com.artcurator.service;

public class SellerServiceImpl {

}
