package com.artcurator.service;

public interface BuyerService {

}
