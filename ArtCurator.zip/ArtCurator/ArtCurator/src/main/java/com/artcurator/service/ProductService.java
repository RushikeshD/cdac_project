package com.artcurator.service;

import java.util.List;
import java.util.Optional;

import com.artcurator.pojos.Product;

public interface ProductService {
	List<Product> findAllProducts();
	Product addProduct(Product product,int id);
	Optional<Product> findByName(String name);
	String deleteById(Integer id);
	List<Product> findAllUnsoldProducts();
	List<Product> findAllSoldProducts();
}
