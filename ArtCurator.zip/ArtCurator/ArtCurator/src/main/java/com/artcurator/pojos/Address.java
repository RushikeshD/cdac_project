package com.artcurator.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/*
 * CREATE TABLE Address (
	appartment VARCHAR(50) NOT NULL,
    street VARCHAR(50) NOT NULL,
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    pin VARCHAR(25) NOT NULL,
    u_id INT UNSIGNED NOT NULL,
    FOREIGN KEY (u_id)
		REFERENCES Users (u_id)
		ON DELETE CASCADE
);
 * */

@Entity
@Table(name = "Address")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "apartment", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String apartment;
	
	@Column(name = "street", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String street;
	
	@Column(name = "city", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String city;
	
	@Column(name = "state", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String state;
	
	@Column(name = "country", nullable = false, length = 75)
	@Size(min = 4, max = 75)
	@NotNull
	private String country;
	
	@Column(name = "zip", nullable = false, length = 6)
	@Size(min = 3, max = 6)
	private String pin;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public Address(Integer id, @Size(min = 4, max = 75) @NotNull String apartment,
			@Size(min = 4, max = 75) @NotNull String street, @Size(min = 4, max = 75) @NotNull String city,
			@Size(min = 4, max = 75) @NotNull String state, @Size(min = 4, max = 75) @NotNull String country,
			@Size(min = 3, max = 6) String pin) {
		super();
		this.id = id;
		this.apartment = apartment;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pin = pin;
	}

	public Address() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApartment() {
		return apartment;
	}

	public void setApartment(String apartment) {
		this.apartment = apartment;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", apartment=" + apartment + ", street=" + street + ", city=" + city + ", state="
				+ state + ", country=" + country + ", pin=" + pin + "]";
	}
}
