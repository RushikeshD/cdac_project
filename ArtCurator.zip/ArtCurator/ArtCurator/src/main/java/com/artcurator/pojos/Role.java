package com.artcurator.pojos;

public enum Role {
	BUYER, SELLER
	/* FUTURE SCOPE CUSTOMER_SERVICE, ADMIN, VENDOR*/
}