package com.artcurator.service;

public class BuyerServiceImpl implements BuyerService {

}
