package com.artcurator.pojos;

public enum Role {
	BUYER, SELLER
}