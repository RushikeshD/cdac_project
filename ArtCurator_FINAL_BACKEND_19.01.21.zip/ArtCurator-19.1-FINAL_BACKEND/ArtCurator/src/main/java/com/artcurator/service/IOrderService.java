package com.artcurator.service;

public interface IOrderService {
	String saveOrderHistory(Long user_id);
}
