package com.artcurator.pojos;

public enum Status {
	SOLD, UNSOLD
}
