package com.artcurator.service;

public interface IWalletService {
	String addMoneyToWallet(Long user_id, double amount);
}